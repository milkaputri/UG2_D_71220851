print('=============== MAKANAN ===============')
telur = print('1. Telur Bakar\t\t : Rp 7.000')
lele = print('2. Lele Terbang Mas Bhe\t : Rp 10.000')
coklat = print('3. Es Coklat Lempu\t : Rp 5.000')
doger = print('4. Es Doger Langensari\t : Rp 13.000')
print('==================== PESANAN ===================')
jum_tel = (int(input('Telur Bakar\t :')))
jum_le = (int(input('Lelle Terbang\t :')))
jum_cok = (int(input('Es Coklat\t :')))
jum_dog = (int(input('Es Doger\t :')))
tel = jum_tel * 7000
le = jum_le * 10000
cok = jum_cok * 5000
dog = jum_dog * 13000
print('==================== TOTAL ====================')
print('TOTAL TELUR BAKAR X ', jum_tel, ': Rp ', tel)
print('TOTAL LELE TERBANG X ', jum_le, ': Rp ', le)
print('TOTAL ES COKLAT C', jum_cok, ': Rp ', cok)
print('TOTAL ES DOGER X ', jum_dog, ': Rp ', dog)
print('Jumalah total biaya yang harus dibayar adlaah Rp ', tel + le + cok + dog )