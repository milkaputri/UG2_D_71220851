nomor = str(input('Masukan Nomor Telepon :').split())
if nomor[3,5]:
    nomor == '16'
    print('Anda menggunakan operator Indosat')
elif nomor[3,5]:
    nomor == '14'
    print('Anda menggunakan operator Telkomsel')
else:
    print('Operator anda tidak diketahui')
