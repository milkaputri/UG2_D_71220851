print('!! Selamat Datang di H+ GYM !!')
print('Silahkan pilih menu dibawah ini:\n 1. Menambah Data\n 2. Menampilkan data\n 3. Keluar')
angka: int(input('Silahkan masukan pilihan yang Anda inginkan: '))
while angka == '1':
    nama = str(input(f'Masukan nama pelanggan: '))
    pilih = str(input('Masukan jenis member: {member[0,]}'))
    print('Data sudah berhasil ditambahkan')
    if angka == '2':
        print('--------------------')
        print('Pelanggan\t Member:\n 1.')
        print(f'{nama}\t {pilih}')
