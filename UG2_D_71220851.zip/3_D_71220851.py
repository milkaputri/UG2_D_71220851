brand= input('Masukan brand apa saya yang hendak dibeli (pisahkan dengan koma): ').title().split(',')
satu = int(input(f'Berapa harga barang {brand[0]} ?:'))
if 10000000<satu<25000000:
    dis_1 = print('Diskon Rp.\t', satu*0.1)
elif satu >= 25000000:
    dis_1 = print('Diskon Rp.\t', satu*0.25)
else:
    dis_1 = print('Diskon Rp.\t 0' )
hasil1 = satu*0
dua = int(input(f'Berapa harga barang {brand[1]} ?:'))
if 10000000<dua<25000000:
    dis_2 = print('Diskon Rp.\t', dua*0.1)
elif dua >= 25000000:
    dis_2 = print('Diskon Rp.\t', dua*0.25)
else:
    dis_2 = print('Diskon Rp.\t 0' )
hasil2 = dua*0.25
tiga = int(input(f'Berapa harga barang {brand[2]} ?:'))
if 10000000<tiga<25000000:
    dis_3 = print('Diskon Rp.\t', tiga*0.1)
elif tiga >= 25000000:
    dis_3 = print('Diskon Rp.\t', tiga*0.25)
else:
    dis_3 = print('Diskon Rp.\t 0' )
hasil3 = tiga*0.1
empat = int(input(f'Berapa harga barang {brand[3]} ?:'))
if 10000000<empat<25000000:
    dis_4 = print('Diskon Rp.\t', empat*0.1)
elif empat >= 25000000:
    dis_4 = print('Diskon Rp.\t', empat*0.25)
else:
    dis_4 = print('Diskon Rp.\t 0' )
hasil4 = empat*0.25

total_dis = hasil1+hasil2+hasil3+hasil4
duit = (satu+dua+tiga+empat) - (total_dis)

print('Total diskon yang anda dapatkan adalah sebesar: Rp\t ', total_dis)
print('Total yang harus anda bayarkan adalah: Rp\t\t ', duit)